<?php

namespace gprs\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class gprsAdminBundle extends Bundle
{
}
