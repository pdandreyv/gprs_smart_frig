<?php

namespace gprs\ClientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class gprsClientBundle extends Bundle
{
}
